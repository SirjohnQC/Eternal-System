# Eternal System — Diorama Engine Test

A standalone browser prototype showing the intended *living planetary diorama* concept.

## Run

Open `index.html` in a browser. No server, dependencies, or installation required.

## What this prototype demonstrates

- Deterministic-ish procedural terrain from a planet seed
- Ocean and deep-ocean visual layers
- Procedural vegetation
- Population-driven settlements
- Technology-driven infrastructure and city lights
- Pollution haze
- Atmosphere/cloud movement
- Weather intensity derived from humidity/ocean/temperature
- Procedural volcanoes
- Wildlife and ships as subtle life
- Day/night variation
- Four quick simulation presets

## Important

This is deliberately a visual proof-of-concept, not the final Eternal System renderer.

The key thing to evaluate is the *design direction*: simulation values visibly change the world rather than simply changing UI numbers.

The next implementation should connect these same concepts to Eternal System's real simulation state and rendering architecture.
